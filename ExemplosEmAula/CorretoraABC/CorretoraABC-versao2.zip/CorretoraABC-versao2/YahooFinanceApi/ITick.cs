﻿using System;
namespace YahooFinanceApi
{
    public interface ITick
    {
        DateTime DateTime { get; }
    }
}
