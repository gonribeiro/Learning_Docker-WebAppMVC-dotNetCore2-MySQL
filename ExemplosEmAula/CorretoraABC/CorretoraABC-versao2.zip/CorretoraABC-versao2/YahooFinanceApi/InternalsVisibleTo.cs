﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("YahooFinanceApi.Tests")]
